#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v node >/dev/null 2>&1; then
  task_node="$(command -v node)"
else
  task_node="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
fi
if [[ ! -x "$task_node" ]]; then
  echo '请先安装 Node.js，再运行本项目。'
  exit 1
fi
export PATH="$(dirname "$task_node"):$PATH"
task_action="${1:-preview}"
case "$task_action" in
  preview) exec "$task_node" node_modules/@remotion/cli/remotion-cli.js studio src/index.ts --port=3100 ;;
  check) exec "$task_node" node_modules/typescript/bin/tsc --noEmit ;;
  verify) exec "$task_node" scripts/verify.mjs ;;
  p03) exec "$task_node" scripts/render-p03.mjs "${2:-all}" ;;
  verify-p03) exec "$task_node" scripts/verify-p03.mjs ;;
  *) exec "$task_node" scripts/render.mjs "$task_action" ;;
esac
