# Karchun Racing 威廉姆斯 2026 MG 动画测试

已追加独立的 P03 透明技术叠加素材：加速 7 秒、制动 7 秒、过弯 8 秒。[P03 制作与使用说明](P03_制作与使用说明.md)，成片位于 `exports/P03/`。原 G01/G02 的内容、样式与导出文件保持原样。

两段可以直接导入剪辑软件的无声 MG 动画。G01 为 12 秒动态数据对比，G02 为 15 秒研发与制造流程示意，串联演示为 27 秒。全部采用 1920×1080、16:9、30fps、H.264、yuv420p，底部 y914 至 1004 留给后期字幕。

## 直接观看

- [G01 期待与现实](exports/G01_期待与现实_12秒.mp4)
- [G02 研发与制造如何衔接](exports/G02_研发与制造如何衔接_15秒.mp4)
- [两段串联演示](exports/KarchunRacing_威廉姆斯_MG演示_27秒.mp4)

本次是画面测试，声音留给正式旁白和后期混音。

## 预览和渲染

本机双击「启动预览.command」或在终端运行：

```bash
./run.sh preview
```

浏览器打开 `http://localhost:3100`。选择 G01、G02 或 Demo，使用播放、逐帧及时间线拖动实时检查。修改源码后预览自动更新。网页预览和 MP4 共用相同组件与逐帧时间计算。

分别渲染、串联渲染以及类型检查：

```bash
./run.sh G01
./run.sh G02
./run.sh Demo
./run.sh all
./run.sh stills
./run.sh check
```

也可使用 `pnpm start`、`pnpm render:g01`、`pnpm render:g02`、`pnpm render:demo`、`pnpm render:all` 和 `pnpm check`。输出写入 `exports/`，关键帧写入 `qa/`。

首次移到其他电脑时，安装 Node.js 及 pnpm，然后在本目录运行 `pnpm install --frozen-lockfile`。`pnpm-workspace.yaml` 只允许 esbuild 所需的安装脚本。首次渲染时 Remotion 会下载渲染浏览器；本机已经准备完成。字体随依赖安装并在渲染前等待加载，不使用在线字体 CDN。

## 修改和扩展

- `src/project.ts`：修改成绩数据、统计阶段、文案、品牌、资料日期、颜色、画布、帧率、片长及主要时间点。时间点为帧数，`seconds()` 可将秒转换为帧。
- `src/G01.tsx`：左右卡片、数字滚动及收尾问题。卡片内的年度口径始终和数据绑定，不计算同比比例。
- `src/G02.tsx`：双区域、六个通用节点及跨区连接。最后的结论与流程示意标识独立呈现。
- `src/components/Primitives.tsx`：可复用的遮罩揭示、字体加载、背景、标题、数字滚动、动态箭头及来源区。
- `src/motion.ts`：共用强缓出、缓入缓出曲线及小幅弹性强调。所有变化均由当前帧驱动，无 CSS animation、随机数、实时计时器或异步运动状态。
- `src/Root.tsx`：G01、G02、Demo 的注册，以及独立的 P03 Composition 文件夹入口。
- `remotion.config.ts` 与 `scripts/render.mjs`：渲染格式、画质及批量导出。

G01 的时间安排为开场 0–2 秒、2025 卡片 2–5 秒、2026 卡片 5–8 秒、对照 8–10 秒、问题收尾 10–12 秒。G02 为标题与区域 0–3 秒、研发节点 3–6 秒、衔接与制造节点 6–9 秒、关键解释 9–12 秒、结论停留 12–15 秒。

Studio 的输入属性可设置 `reducedMotion: true`，用较轻的出现方式替代大位移与数字滚动。默认交付使用完整运动版本；此属性是显式设置，操作系统的动画偏好不会改变离线渲染结果。

## 内容口径与来源

依据上一级横屏制作包中的《威廉姆斯2026横屏视频制作手册》。本次将已有材料制作成动画，资料截止日期仍为 2026 年 10 月 18 日。

- G01：2025 全年，第 5、137 分；2026 截至新加坡，第 9、12 分。两种阶段不同，不计算同比降幅。
- G02：沃尔斯公开解释下的一般流程示意。概念设计、气动研发、设计方案、零件生产、装配集成、测试验证为通用标签；连线没有表示实际日期、工期、完成率或车队内部生产计划。
- [S01 F1 2025 车队积分](https://www.formula1.com/en/results/2025/team)
- [S02 F1 2026 车队积分](https://www.formula1.com/en/results/2026/team)
- [S04 沃尔斯关于冬季研发和制造的解释](https://www.formula1.com/en/latest/article/vowles-explains-why-williams-had-messy-winter-as-team-bounce-back-with-miami-double-points-finish.695XvQJgGKaoBh0Vsf4s02.695XvQJgGKaoBh0Vsf4s02)

所有面板、线条和流程均用 React 与 SVG 原创绘制，没有复制 F1 或 Sky Sports 的标志、转播模板或第三方赛车图片。字体使用本地依赖中的 Noto Sans SC 与 Barlow Condensed，依赖包保留各自许可文件。

## 检查

```bash
./run.sh verify
```

核对三条视频的编码、画幅、帧率、时长、帧数及像素格式，完整解码检查，并检查取样帧确有变化。报告保存在 `exports/媒体检查.json`。验证脚本使用 Remotion 随附的 FFmpeg 与 FFprobe；本次在 Apple Silicon macOS 完成验证。
