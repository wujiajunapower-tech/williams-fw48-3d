# P03 F1 preview asset, revision 2

`f1-car-v2.png`: generated using the built-in imagegen tool on 2026-10-21. Transparent 1536×1024 RGBA asset, copied into the project. Used only by `src/p03/Preview.tsx`, never by the transparent MOV compositions.

Original unbranded modern Formula One demonstrator, not an exact Williams FW48 reconstruction. Replaces the first version's crude polygon car. The car itself is a still raster illustration; the SVG technical overlays, positions, trajectory and timing remain deterministic Remotion code. No Blender or extra dependency.

Prompt: photorealistic contemporary Formula One single-seater, original deep royal blue / navy with restrained pale-blue and white, elevated front-left three-quarter view, front pointing lower right. Credible long low chassis, tapered nose, multi-element front wing and rear wing, exposed black slick tyres and rims, halo cockpit and helmeted driver, airbox, sculpted sidepods, carbon floor and wishbones. Neutral soft studio lighting, whole car visible, transparent background. No logos, sponsors, text, watermark, cartoon, toy, low-poly or generic wedge. Engineering appearance reference only; no dimensional accuracy claim.

The small plan-view cars are independently authored SVG in `src/p03/Primitives.tsx`, not extracted from this image.
