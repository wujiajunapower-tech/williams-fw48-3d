import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';
import {ensureBrowser, openBrowser, selectComposition, renderStill, renderMedia} from '@remotion/renderer';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
process.chdir(root);
process.env.PATH=path.dirname(process.execPath)+path.delimiter+(process.env.PATH||'');
const command=process.argv[2]||'all';
const allowed=['all','G01','G02','Demo','stills'];
if(!allowed.includes(command))throw Error('Choose all, G01, G02, Demo, or stills');
await fs.mkdir(path.join(root,'exports'),{recursive:true});
await fs.mkdir(path.join(root,'qa'),{recursive:true});
await ensureBrowser();
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),outDir:path.join(root,'.cache/bundle'),onProgress:()=>{}});
const browser=await openBrowser('chrome');
const inputProps={reducedMotion:false};
const files={G01:'G01_期待与现实_12秒.mp4',G02:'G02_研发与制造如何衔接_15秒.mp4',Demo:'KarchunRacing_威廉姆斯_MG演示_27秒.mp4'};
try{
  if(command==='stills'){
    const frames={G01:[0,25,65,90,125,155,190,230,275,335,359],G02:[0,50,100,145,195,230,275,325,390,449]};
    for(const [id,list] of Object.entries(frames)){
      const composition=await selectComposition({serveUrl,id,inputProps,puppeteerInstance:browser});
      for(const frame of list){
        await renderStill({serveUrl,composition,frame,inputProps,puppeteerInstance:browser,imageFormat:'png',output:path.join(root,'qa',`${id}-${String(frame).padStart(3,'0')}.png`)});
        console.log(`Still ${id} ${frame}`);
      }
    }
  }else{
    const ids=command==='all'?['G01','G02','Demo']:[command];
    for(const id of ids){
      const composition=await selectComposition({serveUrl,id,inputProps,puppeteerInstance:browser});
      let last=-1;
      await renderMedia({
        serveUrl,composition,inputProps,puppeteerInstance:browser,
        codec:'h264',crf:17,pixelFormat:'yuv420p',imageFormat:'png',
        outputLocation:path.join(root,'exports',files[id]),
        concurrency:4,logLevel:'warn',
        onProgress:({progress})=>{const p=Math.floor(progress*10)*10;if(p!==last){last=p;console.log(`${id} ${p}%`);}},
      });
      console.log(`Saved ${files[id]}`);
    }
  }
}finally{await browser.close({silent:true});}
