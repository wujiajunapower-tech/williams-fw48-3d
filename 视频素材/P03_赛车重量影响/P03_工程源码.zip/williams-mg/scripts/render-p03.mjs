import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';
import {ensureBrowser,openBrowser,selectComposition,renderMedia,renderStill,renderFrames} from '@remotion/renderer';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
process.chdir(root);
process.env.PATH=path.dirname(process.execPath)+path.delimiter+(process.env.PATH||'');
const action=process.argv[2]||'all';
const out=path.join(root,'exports/P03'),qa=path.join(root,'qa/p03');
await fs.mkdir(out,{recursive:true});await fs.mkdir(qa,{recursive:true});
const jobs=[
  {id:'P03-A',file:'P03_A_Acceleration.mov',frames:210},
  {id:'P03-B',file:'P03_B_Braking.mov',frames:210},
  {id:'P03-C',file:'P03_C_Cornering.mov',frames:240},
  {id:'P03-A-Preview',file:'P03_A_Preview.mp4',tone:'bright'},
  {id:'P03-B-Preview',file:'P03_B_Preview.mp4',tone:'dark'},
  {id:'P03-C-Preview',file:'P03_C_Preview.mp4',tone:'bright'},
  {id:'P03-Demo',file:'P03_Combined_Demo.mp4'},
];
const legal=['all','alpha','previews','stills','png',...jobs.map(j=>j.id)];
if(!legal.includes(action))throw Error(`Choose ${legal.join(', ')}`);
await ensureBrowser();
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),outDir:path.join(root,'.cache/p03-bundle'),onProgress:()=>{}});
const browser=await openBrowser('chrome');
const select=(id,inputProps)=>selectComposition({serveUrl,id,inputProps,puppeteerInstance:browser});
const base={serveUrl,puppeteerInstance:browser,imageFormat:'png',concurrency:4,logLevel:'warn',muted:true};
async function pngFallback(job,composition,inputProps){
  const outputDir=path.join(out,`${job.id}-PNG`);
  await fs.mkdir(outputDir,{recursive:true});
  await renderFrames({...base,composition,inputProps,outputDir,onFrameUpdate:f=>{if(f%30===0)console.log(`${job.id} PNG ${f}`);}});
  console.log(`PNG sequence retained: ${outputDir}`);
}
try{
  if(action==='stills'){
    for(const job of jobs.slice(0,3)){
      const inputProps={reducedMotion:false};
      const composition=await select(job.id,inputProps);
      const frames=[0,15,40,65,83,110,145,165,185,...(job.frames===240?[215,230,239]:[199,209])];
      for(const frame of frames){
        await renderStill({...base,composition,inputProps,frame,output:path.join(qa,`${job.id}-${String(frame).padStart(3,'0')}.png`)});
      }
      for(const tone of ['bright','dark']){
        const props={reducedMotion:false,tone,showGuides:true};
        const preview=await select(`${job.id}-Preview`,props);
        for(const frame of [110,165])await renderStill({...base,composition:preview,inputProps:props,frame,output:path.join(qa,`${job.id}-${tone}-${frame}.png`)});
        if(job.id==='P03-A'){
          const plateProps={...props,showOverlay:false};
          const plate=await select(`${job.id}-Preview`,plateProps);
          await renderStill({...base,composition:plate,inputProps:plateProps,frame:110,output:path.join(qa,`plate-${tone}-110.png`)});
        }
      }
      console.log(`QA stills saved: ${job.id}`);
    }
  }else{
    const chosen=action==='all'?jobs:action==='alpha'||action==='png'?jobs.slice(0,3):action==='previews'?jobs.slice(3):jobs.filter(j=>j.id===action);
    for(const job of chosen){
      const alpha=job.file.endsWith('.mov');
      const inputProps={reducedMotion:false,...(!alpha?{showGuides:true}:{}),...(job.tone?{tone:job.tone}:{})};
      const composition=await select(job.id,inputProps);
      if(action==='png'){await pngFallback(job,composition,inputProps);continue;}
      let last=-1;
      try{
        await renderMedia({...base,composition,inputProps,
          ...(alpha?{codec:'prores',proResProfile:'4444',pixelFormat:'yuva444p10le'}:{codec:'h264',crf:17,pixelFormat:'yuv420p',x264Preset:'medium'}),
          outputLocation:path.join(out,job.file),
          onProgress:({progress})=>{const p=Math.floor(progress*10)*10;if(p!==last){last=p;console.log(`${job.id} ${p}%`);}},
        });
      }catch(error){
        if(alpha){console.error(`MOV failed. Retaining transparent PNGs for ${job.id}.`);await pngFallback(job,composition,inputProps);}
        throw error;
      }
      console.log(`Saved ${job.file}`);
    }
  }
}finally{await browser.close({silent:true});}
