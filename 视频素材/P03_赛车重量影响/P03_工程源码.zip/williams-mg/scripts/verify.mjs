import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const requireRenderer=createRequire(import.meta.resolve('@remotion/renderer'));
const platformPackage=process.platform==='darwin'
  ? `@remotion/compositor-darwin-${process.arch}`
  : `@remotion/compositor-linux-${process.arch}-gnu`;
const bin=path.dirname(requireRenderer.resolve(`${platformPackage}/package.json`));
const env={...process.env,DYLD_LIBRARY_PATH:bin+(process.env.DYLD_LIBRARY_PATH?':'+process.env.DYLD_LIBRARY_PATH:'')};
const run=(tool,args,binary=false)=>{
  const p=spawnSync(path.join(bin,tool),args,{env,encoding:binary?null:'utf8',maxBuffer:32*1024*1024});
  if(p.status!==0)throw Error(`${tool} failed: ${p.stderr}`);
  return p.stdout;
};
const expected=[
  ['G01_期待与现实_12秒.mp4',12,360],
  ['G02_研发与制造如何衔接_15秒.mp4',15,450],
  ['KarchunRacing_威廉姆斯_MG演示_27秒.mp4',27,810],
];
const report=[];
for(const [file,duration,frames] of expected){
  const full=path.join(root,'exports',file);
  const info=JSON.parse(run('ffprobe',['-v','error','-count_frames','-show_streams','-show_format','-of','json',full]));
  const v=info.streams.find(s=>s.codec_type==='video');
  const ratio=v.avg_frame_rate.split('/').map(Number);
  const fps=ratio[0]/ratio[1];
  if(v.width!==1920||v.height!==1080||fps!==30||v.pix_fmt!=='yuv420p'||v.codec_name!=='h264'||Number(v.nb_read_frames)!==frames||Math.abs(Number(info.format.duration)-duration)>.001){
    throw Error(`Unexpected format for ${file}`);
  }
  run('ffmpeg',['-v','error','-i',full,'-c:v','rawvideo','-f','null','-']);
  const samples=run('ffmpeg',['-v','error','-i',full,'-vf','scale=w=320:h=180','-r','2','-c:v','rawvideo','-pix_fmt','rgb24','-f','image2pipe','-'],true);
  const frameBytes=320*180*3;
  if(samples.length%frameBytes!==0)throw Error(`Invalid raw frames for ${file}`);
  const hashes=[];
  for(let i=0;i<samples.length;i+=frameBytes)hashes.push(createHash('sha256').update(samples.subarray(i,i+frameBytes)).digest('hex'));
  const unique=new Set(hashes).size;
  if(unique<8)throw Error(`Insufficient changing frames for ${file}`);
  report.push({file,codec:v.codec_name,width:v.width,height:v.height,fps,durationSeconds:duration,frameCount:frames,pixelFormat:v.pix_fmt,decode:'passed',sampledDistinctFrames:unique,bytes:(await fs.stat(full)).size});
  console.log(`PASS ${file}: ${frames} frames / ${duration}s / 1920×1080 / 30fps / H.264, full decode clean`);
}
await fs.writeFile(path.join(root,'exports','媒体检查.json'),JSON.stringify(report,null,2)+'\n');
