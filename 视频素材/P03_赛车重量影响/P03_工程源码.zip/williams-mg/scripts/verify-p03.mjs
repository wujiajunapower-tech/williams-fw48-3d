import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const req=createRequire(import.meta.resolve('@remotion/renderer'));
const pkg=process.platform==='darwin'?`@remotion/compositor-darwin-${process.arch}`:`@remotion/compositor-linux-${process.arch}-gnu`;
const bin=path.dirname(req.resolve(`${pkg}/package.json`));
const env={...process.env,DYLD_LIBRARY_PATH:bin+(process.env.DYLD_LIBRARY_PATH?':'+process.env.DYLD_LIBRARY_PATH:'')};
const run=(tool,args,binary=false)=>{
  const p=spawnSync(path.join(bin,tool),args,{env,encoding:binary?null:'utf8',maxBuffer:64*1024*1024});
  if(p.status!==0||p.stderr?.length)throw Error(`${tool}: ${p.stderr}`);
  return p.stdout;
};
const assert=(test,message)=>{if(!test)throw Error(message);};
const digest=data=>createHash('sha256').update(data).digest('hex');
const expected=[
  ['P03_A_Acceleration.mov',210,true],['P03_B_Braking.mov',210,true],['P03_C_Cornering.mov',240,true],
  ['P03_A_Preview.mp4',210,false],['P03_B_Preview.mp4',210,false],['P03_C_Preview.mp4',240,false],['P03_Combined_Demo.mp4',660,false],
];

function analyseRgba(raw,width,height){
  assert(raw.length===width*height*4,'Invalid RGBA frame length');
  let zero=0,partial=0,opaque=0,min=255,max=0,carMax=0,subtitleMax=0;
  const sx=width/1920,sy=height/1080;
  const x1=Math.ceil(560*sx),x2=Math.floor(1360*sx),y1=Math.ceil(310*sy),y2=Math.floor(840*sy);
  const sub1=Math.ceil(914*sy),sub2=Math.floor(1004*sy);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const a=raw[(y*width+x)*4+3];
    if(a===0)zero++;else if(a===255)opaque++;else partial++;
    if(a<min)min=a;if(a>max)max=a;
    if(x>=x1&&x<x2&&y>=y1&&y<y2&&a>carMax)carMax=a;
    if(y>=sub1&&y<sub2&&a>subtitleMax)subtitleMax=a;
  }
  return {min,max,zero,partial,opaque,carMax,subtitleMax};
}

async function scanAlpha(full,frames){
  const w=480,h=270,bytes=w*h*4;
  const p=spawn(path.join(bin,'ffmpeg'),['-v','error','-i',full,'-vf',`scale=w=${w}:h=${h}`,'-pix_fmt','rgba','-c:v','rawvideo','-f','image2pipe','-'],{env});
  let pending=Buffer.alloc(0),error='',n=0,maxCar=0,maxSubtitle=0,first,last,active=0;
  const hashes=new Set();
  p.stderr.on('data',c=>{error+=c;});
  const done=new Promise((resolve,reject)=>{p.on('error',reject);p.on('close',code=>code===0?resolve():reject(Error(error)));});
  for await(const chunk of p.stdout){
    pending=Buffer.concat([pending,chunk]);
    while(pending.length>=bytes){
      const raw=pending.subarray(0,bytes);pending=pending.subarray(bytes);
      const a=analyseRgba(raw,w,h);if(n===0)first=a;last=a;
      maxCar=Math.max(maxCar,a.carMax);maxSubtitle=Math.max(maxSubtitle,a.subtitleMax);
      if(a.max>0)active++;
      hashes.add(digest(raw));n++;
    }
  }
  await done;
  assert(!error&&pending.length===0&&n===frames,`Alpha decode frame count/error: ${n}/${frames} ${error}`);
  assert(first.max===0&&last.max===0,'Overlay must be fully clear at first and last frames');
  assert(maxCar===0&&maxSubtitle===0,'Overlay intrudes into protected car/subtitle region');
  assert(hashes.size>45&&active>frames*.7,'Missing animation or unexpectedly brief graphics');
  return {decodedFrames:n,analysisResolution:[w,h],firstFrameAlphaMax:first.max,lastFrameAlphaMax:last.max,carCorridorAlphaMax:maxCar,subtitleZoneAlphaMax:maxSubtitle,activeFrames:active,distinctFrames:hashes.size};
}

const report={createdAt:new Date().toISOString(),files:[],regression:{},notes:[
  'All MOV frames decoded to RGBA at 480x270; protected-zone alpha checked in every frame.',
  'Full-resolution frame 110 additionally checked, saved, and composited onto bright/dark placeholder plates.',
  'ProRes 4444 decoder reports yuva444p12le; encoder input is yuva444p10le with PNG capture.',
]};
for(const [file,frames,alpha] of expected){
  const full=path.join(root,'exports/P03',file);
  const info=JSON.parse(run('ffprobe',['-v','error','-count_frames','-show_streams','-show_format','-of','json',full]));
  const v=info.streams.find(s=>s.codec_type==='video');
  assert(v.width===1920&&v.height===1080&&v.avg_frame_rate==='30/1',`Wrong dimensions/fps: ${file}`);
  assert(Number(v.nb_read_frames)===frames&&Number(v.nb_frames)===frames,`Wrong frame count: ${file}`);
  assert(Math.abs(Number(info.format.duration)-frames/30)<.001,`Wrong duration: ${file}`);
  assert(info.streams.every(s=>s.codec_type!=='audio'),`Unrequested audio: ${file}`);
  // The minimal bundled FFprobe emits numeric profile 4 rather than its name.
  assert(alpha?v.codec_name==='prores'&&['4444','4'].includes(v.profile)&&v.codec_tag_string==='ap4h'&&v.pix_fmt.startsWith('yuva444p'):v.codec_name==='h264'&&v.pix_fmt==='yuv420p',`Wrong codec/pixel format: ${file}`);
  const item={file,codec:v.codec_name,profile:v.profile,pixelFormat:v.pix_fmt,tag:v.codec_tag_string,width:v.width,height:v.height,fps:30,frames,duration:frames/30,bytes:(await fs.stat(full)).size,decoded:'passed'};
  if(alpha){
    item.alphaScan=await scanAlpha(full,frames);
    const rgba=run('ffmpeg',['-v','error','-ss',String(110/30),'-i',full,'-frames:v','1','-pix_fmt','rgba','-c:v','rawvideo','-f','image2pipe','-'],true);
    item.fullResolutionAlpha=analyseRgba(rgba,1920,1080);
    const a=item.fullResolutionAlpha;
    assert(a.min===0&&a.max===255&&a.partial>1000&&a.zero>1920*1080*.75,'Alpha channel lacks real transparency/antialiasing');
    assert(a.carMax===0&&a.subtitleMax===0,'Full-res protected region violation');
    // Save an actual decoded MOV frame, not a source-only proof of transparency.
    const png=run('ffmpeg',['-v','error','-ss',String(110/30),'-i',full,'-frames:v','1','-pix_fmt','rgba','-c:v','png','-f','image2pipe','-'],true);
    await fs.writeFile(path.join(root,'qa/p03',file.replace('.mov','-decoded.png')),png);
  }
  report.files.push(item);
  console.log(`PASS ${file}: ${frames} frames, ${item.pixelFormat}${alpha?', genuine alpha, protected regions clear':''}`);
}
const baseline=JSON.parse(await fs.readFile(path.join(root,'qa/p03/g01-g02-baseline.json'),'utf8'));
for(const [file,hash] of Object.entries(baseline)){
  assert(digest(await fs.readFile(path.join(root,file)))===hash,`G01/G02 changed: ${file}`);
}
report.regression={status:'passed',unchangedFiles:Object.keys(baseline)};
await fs.writeFile(path.join(root,'exports/P03/P03_媒体与透明通道检查.json'),JSON.stringify(report,null,2)+'\n');
console.log('PASS G01/G02 source primitives and existing MP4 hashes unchanged.');
