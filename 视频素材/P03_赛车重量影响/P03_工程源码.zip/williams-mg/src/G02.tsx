import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {CONTENT, PALETTE as C, TIMING, SceneProps} from './project';
import {lerp, progress, settle} from './motion';
import {Background, DrawArrow, Footer, FontGate, Reveal, SceneTitle} from './components/Primitives';

const Region: React.FC<{frame:number; right?:boolean; reduced:boolean}> = ({frame,right=false,reduced}) => {
  const p=progress(frame,TIMING.G02.regions+(right?6:0),30);
  const focus=progress(frame,TIMING.G02.explanation,26);
  const x=right?1020:96;
  return <div style={{position:'absolute',left:x,top:323,width:804,height:366,
    transform:`translateY(${reduced?0:(1-p)*45}px)`,opacity:p,
    border:`1px solid ${right&&focus>.2?'#7B914D':'#2B4B70'}`,
    background:right?'linear-gradient(130deg,#122945D9,#0C1C32E6)':'linear-gradient(130deg,#14355BE6,#102843D9)',borderRadius:3}}>
    <div style={{position:'absolute',top:23,left:29,fontSize:21,letterSpacing:3,color:right?C.muted:C.ice}}>{right?'02 / MANUFACTURING':'01 / DEVELOPMENT'}</div>
    <div style={{position:'absolute',top:61,left:29,fontSize:37,fontWeight:600,letterSpacing:1}}>{right?'制造与验证':'研发'}</div>
    <div style={{position:'absolute',top:77,right:28,color:C.muted,fontSize:22}}>{right?'生产 · 装配 · 验证':'概念 · 气动 · 方案'}</div>
    <div style={{position:'absolute',left:29,top:121,width:746,height:1,background:'#375577'}}/>
    <Reveal frame={frame} at={right?TIMING.G02.explanation:TIMING.G02.research[2]+18} reduced={reduced} style={{position:'absolute',left:29,top:310,height:40}}>
      <div style={{fontSize:23,color:right?C.lime:C.ice,lineHeight:'35px'}}>{right?'后续工作仍需分别完成':'风洞工作可以提前启动'}</div>
    </Reveal>
  </div>;
};

const FlowNode:React.FC<{frame:number;at:number;x:number;label:string;index:number;right:boolean;reduced:boolean}> = ({frame,at,x,label,index,right,reduced}) => {
  const p=progress(frame,at,reduced?8:23);
  const line=settle(frame,at+5);
  const focus=progress(frame,TIMING.G02.explanation,22);
  const color=right&&focus>.1?C.lime:C.ice;
  return <div style={{position:'absolute',left:x,top:478,width:210,height:136,
    opacity:Math.min(1,p*4),transform:`translateY(${reduced?0:(1-p)*30}px) scale(${reduced?1:lerp(.97,1,p)})`,
    border:'1px solid #45658B',background:right?'#112B49':'#1A416C',overflow:'hidden'}}>
    <div className="numerals" style={{position:'absolute',left:17,top:10,color,fontSize:25,letterSpacing:2}}>0{index+1}</div>
    <div style={{position:'absolute',left:17,top:60,fontSize:30,lineHeight:'42px',fontWeight:600,letterSpacing:.5}}>{label}</div>
    <div style={{position:'absolute',bottom:0,left:0,width:210,height:3,background:color,transformOrigin:'left',transform:`scaleX(${line})`}}/>
  </div>;
};

export const G02:React.FC<SceneProps> = ({reducedMotion}) => {
  const frame=useCurrentFrame();
  const t=TIMING.G02;
  const bridge=progress(frame,t.bridge,26);
  const explanation=progress(frame,t.explanation,22);
  const ending=progress(frame,t.conclusion,22);
  const leftXs=[126,393,660];
  const rightXs=[1050,1317,1584];
  const [conclusionLeft,conclusionRight]=CONTENT.G02.conclusion.split('≠').map(s=>s.trim());
  return <AbsoluteFill className="scene">
    <FontGate/>
    <Background frame={frame} code="G02" reduced={reducedMotion}/>
    <SceneTitle frame={frame} at={t.titleIn} title={CONTENT.G02.title} subtitle={CONTENT.G02.subtitle} reduced={reducedMotion}/>
    <Region frame={frame} reduced={reducedMotion}/><Region frame={frame} right reduced={reducedMotion}/>
    <svg width="1920" height="1080" style={{position:'absolute',inset:0}}>
      {[0,1].map(i=><DrawArrow key={`l${i}`} x1={leftXs[i]+219} x2={leftXs[i+1]-10} y={546} frame={frame} at={t.research[i]+16} duration={18} reduced={reducedMotion}/>)}
      {[0,1].map(i=><DrawArrow key={`r${i}`} x1={rightXs[i]+219} x2={rightXs[i+1]-10} y={546} frame={frame} at={t.manufacture[i]+16} duration={18} color={C.ice} reduced={reducedMotion}/>)}
      <path d="M908 514H1012 M908 578H1012" stroke="#355477" strokeWidth="1" opacity={bridge*.6}/>
      <DrawArrow x1={918} x2={1000} y={546} frame={frame} at={t.bridge} duration={26} color={explanation>.1?C.lime:C.ice} reduced={reducedMotion}/>
    </svg>
    {CONTENT.G02.research.map((label,i)=><FlowNode key={label} frame={frame} at={t.research[i]} x={leftXs[i]} label={label} index={i} right={false} reduced={reducedMotion}/>)}
    {CONTENT.G02.manufacture.map((label,i)=><FlowNode key={label} frame={frame} at={t.manufacture[i]} x={rightXs[i]} label={label} index={i} right reduced={reducedMotion}/>)}
    <Reveal frame={frame} at={t.bridge+4} duration={20} reduced={reducedMotion} style={{position:'absolute',left:908,top:444,width:104,textAlign:'center',height:40}}>
      <div style={{fontSize:23,lineHeight:'35px',color:C.ice}}>衔接</div>
    </Reveal>
    <div style={{position:'absolute',left:96,top:721,width:1728,textAlign:'center',height:92}}>
      <div style={{position:'absolute',inset:0,opacity:1-ending,transform:`translateY(${reducedMotion?0:-ending*20}px)`}}>
        <Reveal frame={frame} at={t.explanation} duration={26} reduced={reducedMotion}>
          <div style={{fontSize:43,lineHeight:'74px',fontWeight:600}}>{CONTENT.G02.handoff}</div>
        </Reveal>
      </div>
      <div style={{position:'absolute',inset:0,opacity:ending,transform:`translateY(${reducedMotion?0:(1-ending)*30}px)`}}>
        <div style={{fontSize:43,lineHeight:'74px',fontWeight:600}}>
          <span>{conclusionLeft}</span><span style={{color:C.lime,margin:'0 22px',fontSize:53}}>≠</span><span>{conclusionRight}</span>
        </div>
      </div>
    </div>
    <Footer frame={frame} at={25} top={823} source={CONTENT.G02.source} note={CONTENT.G02.scope}/>
  </AbsoluteFill>;
};
