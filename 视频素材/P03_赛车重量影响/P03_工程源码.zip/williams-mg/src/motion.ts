import {Easing, interpolate, spring} from 'remotion';
import {VIDEO} from './project';

export const OUT = Easing.bezier(0.23, 1, 0.32, 1);
export const IN_OUT = Easing.bezier(0.77, 0, 0.175, 1);
export const progress = (frame: number, at: number, duration: number, easing = OUT) =>
  interpolate(frame, [at, at + duration], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing,
  });

// Use the documented physical spring for small accents; readable data never bounce.
export const settle = (frame: number, at: number) => spring({
  frame: frame - at, fps: VIDEO.fps, durationInFrames: 30,
  config: {mass: 1, stiffness: 100, damping: 10, overshootClamping: true},
});

export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
