import React, {useEffect, useState} from 'react';
import {AbsoluteFill, continueRender, delayRender, cancelRender} from 'remotion';
import {CONTENT, PALETTE as C} from '../project';
import {lerp, progress} from '../motion';

export const FontGate: React.FC = () => {
  const [handle] = useState(() => delayRender('Loading locally bundled Chinese and numeric fonts'));
  useEffect(() => {
    const sample = JSON.stringify(CONTENT) + '研发制造验证衔接车队排名年度积分第名分风洞准备零件生产装配集成概念设计气动';
    Promise.all([
      ...[400, 600, 700].map(w => document.fonts.load(`${w} 48px "Noto Sans SC"`, sample)),
      ...[600, 700].map(w => document.fonts.load(`${w} 128px "Barlow Condensed"`, '0123456789')),
    ]).then(() => continueRender(handle)).catch(cancelRender);
  }, [handle]);
  return null;
};

export const Reveal: React.FC<{
  frame: number; at: number; duration?: number; reduced?: boolean;
  children: React.ReactNode; style?: React.CSSProperties;
}> = ({frame, at, duration = 24, reduced = false, children, style}) => {
  const p = progress(frame, at, reduced ? 8 : duration);
  return <div style={{overflow: 'hidden', ...style}}>
    <div style={{opacity: reduced ? p : Math.min(1, p * 4), transform: `translateY(${reduced ? 0 : (1 - p) * 110}%)`}}>{children}</div>
  </div>;
};

export const Background: React.FC<{frame: number; code: string; reduced: boolean}> = ({frame, code, reduced}) => {
  const p = progress(frame, 0, 40);
  return <AbsoluteFill style={{background: C.background}}>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 35%, #112544 0%, #081322 43%, #060C18 78%)'}} />
    <svg width="1920" height="1080" style={{position: 'absolute', opacity: 0.24}}>
      <defs><pattern id={`grid-${code}`} width="80" height="80" patternUnits="userSpaceOnUse"><path d="M80 0H0V80" stroke="#26415E" strokeWidth="1" fill="none"/></pattern></defs>
      <rect width="1920" height="900" fill={`url(#grid-${code})`}/>
      <path d="M0 708L446 262H780 M1920 708L1474 262H1140" stroke="#456789" strokeWidth="1" fill="none" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/>
      <path d="M40 210V96H350 M1880 210V96H1570" stroke="#6E9BC9" strokeWidth="2" fill="none" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/>
      {[0,1,2,3,4,5,6].map(i => <path key={i} d={`M${50+i*10} 755v${i%2 ? 10 : 20} M${1810+i*10} 755v${i%2 ? 10 : 20}`} stroke="#719BC3" strokeWidth="1"/>)}
    </svg>
    <div style={{position: 'absolute', top: 57, left: 96, fontSize: 20, fontWeight: 600, letterSpacing: 4, color: C.muted, opacity: p}}>WILLIAMS <span style={{color: C.blue}}>/</span> TECHNICAL ANALYSIS</div>
    <div style={{position: 'absolute', top: 57, right: 96, fontSize: 22, fontWeight: 600, letterSpacing: 3, opacity: p}}>{CONTENT.brand}<span style={{color: C.lime, marginLeft: 15}}> /</span></div>
    <div style={{position: 'absolute', left: 96, top: 107, width: 36, height: 3, background: C.blue, transformOrigin: 'left', transform: `scaleX(${reduced ? 1 : p})`}}/>
  </AbsoluteFill>;
};

export const Footer: React.FC<{source: string; frame: number; at?: number; note?: string; top?: number}> = ({source, frame, at=30, note, top=845}) => {
  const p = progress(frame, at, 20);
  return <div style={{position: 'absolute', top, left: 96, width: 1728, opacity: p, color: C.muted}}>
    <div style={{height: 1, background: '#29415F', marginBottom: 15}}/>
    <div style={{display: 'flex', justifyContent: 'space-between', gap: 20, fontSize: 24, lineHeight: '32px'}}>
      <span>{source}</span><span>{CONTENT.asOf}</span>
    </div>
    {note ? <div style={{fontSize: 22, lineHeight: '30px', marginTop: 5, color: '#8297AE'}}>{note}</div> : null}
  </div>;
};

export const SceneTitle: React.FC<{
  frame: number; at: number; title: string; subtitle: string; reduced: boolean;
  introCenter?: boolean; moveAt?: number; moveDuration?: number;
}> = ({frame, at, title, subtitle, reduced, introCenter=false, moveAt=43, moveDuration=22}) => {
  const move = introCenter ? progress(frame, moveAt, moveDuration) : 1;
  const scale = introCenter && !reduced ? lerp(1.47, 1, move) : 1;
  const y = introCenter && !reduced ? lerp(280, 0, move) : 0;
  return <div style={{position: 'absolute', left: 96, top: 120, width: 1728, textAlign: 'center', transform: `translateY(${y}px) scale(${scale})`, transformOrigin: '50% 0%'}}>
    <Reveal frame={frame} at={at} duration={28} reduced={reduced} style={{height: 94}}>
      <div style={{fontSize: 66, lineHeight: '90px', fontWeight: 700, letterSpacing: -2}}>{title}</div>
    </Reveal>
    <Reveal frame={frame} at={at+10} duration={24} reduced={reduced} style={{height: 50, marginTop: 8}}>
      <div style={{fontSize: 28, lineHeight: '44px', fontWeight: 400, color: C.muted, letterSpacing: 2}}>{subtitle}</div>
    </Reveal>
  </div>;
};

export const RollingNumber: React.FC<{
  value: number; frame: number; at: number; reduced: boolean; size?: number; duration?: number;
}> = ({value, frame, at, reduced, size=142, duration=32}) => {
  const digits = String(value).split('').map(Number);
  return <div className="numerals" style={{display: 'flex', height: size, fontWeight: 600, overflow: 'hidden'}} aria-label={String(value)}>
    {digits.map((digit,i) => {
      const p = reduced ? 1 : progress(frame, at+i*2, duration);
      const steps=20+digit;
      return <div key={i} style={{height: size, width: size*0.46, overflow: 'hidden', position: 'relative'}}>
        <div style={{transform: `translateY(${-steps*p*size}px)`}}>
          {Array.from({length: 30}, (_,j) => <div key={j} style={{fontSize: size, height: size, lineHeight: `${size}px`, textAlign: 'center'}}>{j%10}</div>)}
        </div>
      </div>;
    })}
  </div>;
};

export const DrawArrow: React.FC<{
  x1: number; x2: number; y: number; frame: number; at: number; duration?: number; color?: string; reduced?: boolean;
}> = ({x1,x2,y,frame,at,duration=20,color=C.ice,reduced=false}) => {
  const p=progress(frame,at,reduced?8:duration);
  const x=lerp(x1,x2,p);
  return <g opacity={p>0 ? 1 : 0}>
    <path d={`M${x1} ${y}H${x2}`} fill="none" stroke={color} strokeWidth="3" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/>
    <path d={`M${x-9} ${y-6}L${x} ${y}L${x-9} ${y+6}`} fill="none" stroke={color} strokeWidth="3" opacity={Math.min(1,p*3)}/>
  </g>;
};
