import {PALETTE, seconds} from '../project';

/** P03 only. Existing G01/G02 tokens and content remain untouched. */
export const P03_COLOR = {...PALETTE, scrim: 'rgba(6,12,24,0.82)', soft: '#C6D6E7'};
export const P03_LENGTH = {A: seconds(7), B: seconds(7), C: seconds(8)};
export const P03_TIME = {
  title: seconds(0.12), condition: seconds(0.48), intro: seconds(0.85),
  evidence: seconds(2), second: seconds(2.55), third: seconds(3.25),
  conclusion: seconds(5), entrance: 18, exit: 12,
};
export const P03_LAYOUT = {
  left: 96, right: 1404, sideWidth: 420, diagramTop: 334,
  // Keep this corridor and y914–1004 fully clear in transparent renders.
  carClear: {x: 560, y: 310, width: 800, height: 530},
  subtitleClear: {x: 0, y: 914, width: 1920, height: 90},
};
export const P03_COPY = {
  brand: 'KARCHUN RACING', series: 'P03 / VEHICLE MASS',
  scope: '工程关系示意 · 非 FW48 实测数据',
  placeholder: '原创赛车占位背景 · 非实拍',
  subtitle: '后期字幕预留区域  y914–1004',
  A: {
    title: '重量与加速', kicker: '01 / ACCELERATION',
    condition: '其他条件相同 · 可用净驱动力相同的关系示意',
    conclusion: '额外质量增加加速负担',
    smaller: '质量较小', larger: '质量较大',
    force: '相同净驱动力', response: '加速度响应',
    fast: '响应更快', slow: '响应较慢',
    formula: 'a = F净 / m', note: '箭头长度只表示相对关系，不代表实际数值',
  },
  B: {
    title: '重量与制动', kicker: '02 / BRAKING',
    condition: '相同车速下 · 质量越大，车辆动能越高',
    conclusion: '更高的制动能量负担',
    energy: '需要处理的动能', smaller: '质量较小', larger: '质量较大',
    sameSpeed: '相同车速', forward: '前进与减速示意',
    braking: '制动能量管理', heat: '热管理要求更高',
    heatNote: '能量经制动等途径处理',
    formula: 'Eₖ = ½ mv²', note: '不推导固定制动距离增幅 · 不表示实际温度',
  },
  C: {
    title: '重量与过弯', kicker: '03 / CORNERING',
    condition: '相同速度与转弯半径下 · 额外质量提高所需横向力',
    conclusion: '重量影响轮胎负荷与弯道表现',
    path: '弯道轨迹', force: '所需横向力', inward: '方向指向弯心',
    tyre: '轮胎负荷', grip: '抓地响应并非等比例增加',
    sensitivity: '轮胎存在负荷敏感性',
    state: '还取决于轮胎状态等条件',
    formula: 'Fᵧ = mv² / r', note: '轨迹仅作解释 · 不预测实际赛车线路或抓地极限',
  },
};
export type P03Key = keyof typeof P03_LENGTH;
export type P03Props = {reducedMotion: boolean};
export type PreviewProps = P03Props & {tone: 'bright' | 'dark'; showGuides: boolean; showOverlay: boolean};
