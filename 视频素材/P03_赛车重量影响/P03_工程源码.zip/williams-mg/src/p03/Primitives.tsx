import React, {useEffect, useState} from 'react';
import {AbsoluteFill, cancelRender, continueRender, delayRender} from 'remotion';
import {progress, settle} from '../motion';
import {Reveal} from '../components/Primitives';
import {P03_COLOR as C, P03_COPY as T, P03_LENGTH, P03_TIME as TIME, P03Key, P03Props} from './config';

export const P03FontGate: React.FC = () => {
  const [handle] = useState(() => delayRender('P03 local Chinese font subsets'));
  useEffect(() => {
    const sample = JSON.stringify(T) + 'abcdefghijklmnopqrstuvwxyz0123456789力净';
    Promise.all([
      ...[400,600,700].map(w => document.fonts.load(`${w} 40px "Noto Sans SC"`, sample)),
      ...[600,700].map(w => document.fonts.load(`${w} 40px "Barlow Condensed"`, sample)),
    ]).then(() => continueRender(handle)).catch(cancelRender);
  }, [handle]);
  return null;
};

export const textEdge: React.CSSProperties = {
  textShadow: '0 2px 5px rgba(0,0,0,.75)',
};
export const localBacking: React.CSSProperties = {
  background: C.scrim, borderLeft: `3px solid ${C.ice}`,
  boxShadow: '0 3px 12px rgba(0,0,0,.14)',
};

export const Appear:React.FC<{
  f:number; at:number; reduced?:boolean; direction?:number;
  style?:React.CSSProperties; children:React.ReactNode;
}> = ({f,at,reduced=false,direction=1,style,children}) => {
  const p=progress(f,at,reduced?8:TIME.entrance);
  return <div style={{...style, opacity:p, transform:`translateX(${reduced?0:direction*(1-p)*24}px)`}}>{children}</div>;
};

export const OverlayFrame:React.FC<P03Props & {
  id:P03Key; f:number; children:React.ReactNode;
}> = ({id,f,reducedMotion,children}) => {
  const out=progress(f,P03_LENGTH[id]-TIME.exit-1,TIME.exit);
  const start=progress(f,0,8);
  const p=progress(f,TIME.title,18);
  return <AbsoluteFill className="scene" style={{opacity:start*(1-out), overflow:'hidden', ...textEdge}}>
    <P03FontGate/>
    <div style={{position:'absolute',left:96,top:59,color:C.ice,fontSize:20,letterSpacing:3,opacity:p}}>{T.series}</div>
    <div style={{position:'absolute',right:96,top:59,fontSize:21,fontWeight:600,letterSpacing:2,opacity:p}}>{T.brand}<span style={{color:C.lime,marginLeft:12}}>/</span></div>
    <div style={{position:'absolute',left:96,top:105,width:760}}>
      <Reveal frame={f} at={TIME.title} duration={24} reduced={reducedMotion}>
        <div style={{display:'inline-flex',alignItems:'center',gap:19,padding:'4px 22px 10px 15px',background:'linear-gradient(90deg,rgba(6,12,24,.94),rgba(6,12,24,.66) 85%,transparent)'}}>
          <div style={{width:5,height:49,background:C.lime,transform:`scaleY(${reducedMotion?1:settle(f,TIME.title)})`}}/>
          <span style={{fontSize:56,fontWeight:700,lineHeight:'78px',letterSpacing:-1}}>{T[id].title}</span>
        </div>
      </Reveal>
    </div>
    <Appear f={f} at={TIME.condition} reduced={reducedMotion} style={{position:'absolute',left:96,top:210}}>
      <div style={{opacity:1-progress(f,TIME.conclusion-8,8)}}>
      <div style={{...localBacking,padding:'11px 19px',fontSize:28,lineHeight:'40px',color:C.soft}}>{T[id].condition}</div>
      </div>
    </Appear>
    {children}
    <Appear f={f} at={TIME.conclusion} reduced={reducedMotion} style={{position:'absolute',left:96,top:210}}>
      <div style={{...localBacking,borderLeftColor:C.lime,padding:'12px 24px',fontSize:38,fontWeight:600,lineHeight:'53px'}}>
        <span style={{color:C.lime,marginRight:20,fontSize:26}}>→</span>{T[id].conclusion}
      </div>
    </Appear>
    <Appear f={f} at={TIME.intro} reduced={reducedMotion} style={{position:'absolute',left:96,top:862,display:'flex',gap:22,fontSize:20,lineHeight:'28px',color:C.soft}}>
      <span style={{background:'rgba(6,12,24,.85)',padding:'3px 12px'}}>{T.scope}</span>
      <span style={{background:'rgba(6,12,24,.85)',padding:'3px 12px'}}>{T[id].note}</span>
    </Appear>
  </AbsoluteFill>;
};

export const SideHeading:React.FC<{x:number;y:number;f:number;at:number;label:string;tag:string;reduced:boolean}> = ({x,y,f,at,label,tag,reduced}) =>
  <Appear f={f} at={at} reduced={reduced} style={{position:'absolute',left:x,top:y,width:420}}>
    <div style={{...localBacking,padding:'10px 16px',fontSize:29,fontWeight:600,lineHeight:'40px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      {label}<span className="numerals" style={{fontSize:23,letterSpacing:2,color:C.ice}}>{tag}</span>
    </div>
  </Appear>;

/** Arrowhead follows the growing vector, including for negative/inward directions. */
export const Vector:React.FC<{x:number;y:number;dx:number;dy:number;p?:number;color?:string;width?:number;dash?:boolean}> = ({x,y,dx,dy,p=1,color=C.ice,width=3,dash=false}) => {
  const angle=Math.atan2(dy,dx)*180/Math.PI;
  const length=Math.hypot(dx,dy)*p;
  return <g transform={`translate(${x} ${y}) rotate(${angle})`} opacity={Math.min(1,p*4,length/11)}>
    <path d={`M0 0H${length}`} stroke={color} strokeWidth={width} fill="none" strokeDasharray={dash?'6 7':undefined}/>
    <path d={`M${length-11} -7L${length} 0L${length-11} 7`} stroke={color} strokeWidth={width} fill="none" strokeLinejoin="round"/>
  </g>;
};

/** Original F1 plan-view schematic. +x forward; long chassis, exposed wheels,
 * tapered nose, multi-element wings, halo, wishbones. No exact FW48 geometry. */
export const PlanCar:React.FC<{x:number;y:number;angle?:number;scale?:number;color?:string}> = ({x,y,angle=0,scale=1,color=C.ice}) =>
  <g transform={`translate(${x} ${y}) rotate(${angle}) scale(${scale})`} stroke={color} strokeWidth="1.35" strokeLinejoin="round">
    <path d="M-56-12Q-38-23-15-20L6-15 16-8V8L6 15-15 20Q-38 23-56 12Z" fill={C.background} fillOpacity=".94"/>
    <g fill="none" strokeOpacity=".8" strokeWidth="1.4">
      <path d="M10-4L43-21 24-3M10 4L43 21 24 3M-27-4L-45-21-55-5M-27 4L-45 21-55 5"/>
    </g>
    <path d="M-59-4Q-43-7-24-14Q-8-18 3-12L19-7 65-3Q73-2 73 0Q73 2 65 3L19 7 3 12Q-8 18-24 14Q-43 7-59 4Z" fill={C.panelBright}/>
    <path d="M-38-10Q-33-18-18-18L-8-14-14-8Z M-38 10Q-33 18-18 18L-8 14-14 8Z" fill={color} fillOpacity=".22"/>
    <path d="M-57-2L-29-7-22-3V3L-29 7-57 2Z" fill={color} fillOpacity=".45"/>
    <ellipse cx="-8" rx="12" ry="7" fill={C.background}/>
    <path d="M-17-7Q0-14 5 0Q0 14-17 7M5 0H13" fill="none" strokeWidth="2"/>
    <ellipse cx="-8" rx="4" ry="4.5" fill={color} stroke="none"/>
    <g fill={C.background}>
      <rect x="-57" y="-28" width="26" height="14" rx="3.2"/><rect x="-57" y="14" width="26" height="14" rx="3.2"/>
      <rect x="33" y="-27" width="23" height="12" rx="3"/><rect x="33" y="15" width="23" height="12" rx="3"/>
    </g>
    <path d="M-52-24H-36M-52 24H-36M37-23H52M37 23H52" stroke={color} strokeOpacity=".4" strokeWidth="1"/>
    <path d="M-72-24L-60-23V23L-72 24Z" fill={C.panel}/>
    <path d="M-68-23V23M-63-22V22" fill="none" strokeWidth=".8"/>
    <path d="M63-6L61-28 76-26 78-16 73-4V4L78 16 76 26 61 28 63 6Z" fill={C.panel}/>
    <path d="M66-27L70-15 67-5M72-26L75-16 70-4M66 27L70 15 67 5M72 26L75 16 70 4" fill="none" strokeWidth=".9"/>
    <path d="M61-28L76-26M61 28L76 26" strokeWidth="2"/>
  </g>;

export const svgText = {fontFamily:'Noto Sans SC',fontSize:24,fill:C.white,paintOrder:'stroke',stroke:C.background,strokeWidth:3,strokeLinejoin:'round'} as const;
