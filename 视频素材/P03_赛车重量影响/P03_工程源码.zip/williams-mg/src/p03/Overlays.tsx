import React from 'react';
import {Easing, useCurrentFrame} from 'remotion';
import {progress} from '../motion';
import {P03_COLOR as C, P03_COPY as T, P03_TIME as TIME, P03_LAYOUT as L, P03Props} from './config';
import {Appear, localBacking, OverlayFrame, PlanCar, SideHeading, svgText, Vector} from './Primitives';

const svgStyle:React.CSSProperties={position:'absolute',filter:'drop-shadow(0 2px 3px rgba(0,0,0,.65))',overflow:'visible'};
const Formula:React.FC<{f:number;at:number;text:string;reduced:boolean}> = ({f,at,text,reduced}) =>
  <Appear f={f} at={at} reduced={reduced} style={{position:'absolute',right:96,top:123}}>
    <div style={{...localBacking,borderLeftColor:C.blue,padding:'7px 20px',fontSize:31,letterSpacing:1,lineHeight:'45px'}}>{text}</div>
  </Appear>;

const AccelerationSide:React.FC<{f:number;heavy:boolean;reduced:boolean}> = ({f,heavy,reduced}) => {
  const x=heavy?L.right:L.left;
  const at=heavy?TIME.second:TIME.evidence;
  const enter=progress(f,at,18);
  // Dimensionless movement is pedagogical, not a measurement or a mass-ratio claim.
  // Same time window, x proportional to t²; both net-force arrows have identical length.
  const t=reduced?1:progress(f,TIME.second+10,59,Easing.linear);
  const distance=(heavy?60:120)*t*t;
  const response=progress(f,TIME.third,20);
  const massColor=heavy?C.lime:C.ice;
  return <>
    <SideHeading x={x} y={L.diagramTop} f={f} at={at} label={heavy?T.A.larger:T.A.smaller} tag={heavy?'m ↑':'m'} reduced={reduced}/>
    <svg width="420" height="350" style={{...svgStyle,left:x,top:410,opacity:enter,transform:`translateX(${reduced?0:(heavy?1:-1)*(1-enter)*25}px)`}}>
      <text x="18" y="28" {...svgText} fill={C.lime}>{T.A.force}</text>
      <Vector x={18} y={55} dx={142} dy={0} p={progress(f,at+7,18)} color={C.lime}/>
      <path d="M20 191H400" stroke={C.soft} strokeOpacity=".45" strokeWidth="2"/>
      {[0,1,2,3,4,5,6,7].map(i=><path key={i} d={`M${22+i*51} 191v9`} stroke={C.soft} strokeWidth="2"/>)}
      <g opacity=".25"><PlanCar x={80} y={151} color={C.soft}/></g>
      <path d={`M80 151H${80+distance}`} fill="none" stroke={massColor} strokeWidth="3" strokeDasharray="4 6"/>
      <PlanCar x={80+distance} y={151} color={massColor}/>
      {heavy?<g transform={`translate(${80+distance} 151)`}><rect x="-14" y="-10" width="26" height="20" rx="2" fill={C.lime}/><path d="M-6-5V5M-11 0H-1" stroke={C.background} strokeWidth="2"/></g>:null}
      <g opacity={response}>
        <text x="18" y="246" {...svgText}>{T.A.response}</text>
        <Vector x={18} y={274} dx={heavy?92:180} dy={0} color={massColor} p={response}/>
        <text x="18" y="320" {...svgText} fill={massColor} fontSize="27" fontWeight="600">{heavy?T.A.slow:T.A.fast}</text>
      </g>
    </svg>
  </>;
};

export const Acceleration:React.FC<P03Props> = ({reducedMotion}) => {
  const f=useCurrentFrame();
  return <OverlayFrame id="A" f={f} reducedMotion={reducedMotion}>
    <Formula f={f} at={TIME.evidence} text={T.A.formula} reduced={reducedMotion}/>
    <Appear f={f} at={TIME.intro} reduced={reducedMotion} style={{position:'absolute',left:96,top:284}}>
      <svg width="420" height="28">{[0,1,2].map(i=><Vector key={i} x={20+i*100} y={14} dx={65} dy={0} p={progress(f,TIME.intro+i*4,18)} color={C.ice}/>)}</svg>
    </Appear>
    <AccelerationSide f={f} heavy={false} reduced={reducedMotion}/><AccelerationSide f={f} heavy reduced={reducedMotion}/>
  </OverlayFrame>;
};

export const Braking:React.FC<P03Props> = ({reducedMotion}) => {
  const f=useCurrentFrame();
  const energy=progress(f,TIME.evidence,18);
  const heavy=progress(f,TIME.second,18);
  const management=progress(f,TIME.third,18);
  const slow=1-progress(f,34,28,Easing.linear);
  const transfer=progress(f,82,28);
  return <OverlayFrame id="B" f={f} reducedMotion={reducedMotion}>
    <Formula f={f} at={TIME.evidence} text={T.B.formula} reduced={reducedMotion}/>
    <Appear f={f} at={TIME.intro} reduced={reducedMotion} style={{position:'absolute',left:1404,top:275}}>
      <svg width="420" height="52" style={{filter:'drop-shadow(0 2px 3px #000)',opacity:1-progress(f,55,13)}}>
        <text x="10" y="20" {...svgText} fontSize="20">{T.B.forward}</text>
        {[0,1,2].map(i=><Vector key={i} x={12+i*120} y={42} dx={reducedMotion?35:90*slow} dy={0} p={progress(f,26+i*3,10)} color={C.ice}/>) }
      </svg>
    </Appear>
    <SideHeading x={96} y={334} f={f} at={TIME.evidence} label={T.B.energy} tag="Eₖ" reduced={reducedMotion}/>
    <svg width="420" height="330" style={{...svgStyle,left:96,top:410,opacity:energy}}>
      <text x="18" y="32" {...svgText} fill={C.soft}>{T.B.sameSpeed}</text>
      <g opacity={energy}>
        <text x="18" y="90" {...svgText}>{T.B.smaller}</text>
        <g transform={`translate(18 115) scale(${energy} 1)`}><rect width="180" height="32" fill={C.ice}/><path d="M0 0H180" stroke={C.white} strokeWidth="2"/></g>
      </g>
      <g opacity={heavy}>
        <text x="18" y="210" {...svgText}>{T.B.larger}</text>
        <g transform={`translate(18 235) scale(${heavy} 1)`}><rect width="300" height="32" fill={C.lime}/><path d="M0 0H300" stroke={C.white} strokeWidth="2"/></g>
      </g>
      <text x="18" y="320" {...svgText} fill={C.soft} fontSize="21">{T.scope}</text>
    </svg>
    <SideHeading x={1404} y={334} f={f} at={TIME.second} label={T.B.braking} tag="ENERGY" reduced={reducedMotion}/>
    <svg width="420" height="330" style={{...svgStyle,left:1404,top:410,opacity:heavy}}>
      <Vector x={12} y={126} dx={82} dy={0} color={C.lime} p={transfer}/>
      {[0,1,2].map(i=>{
        const t=reducedMotion?0.5:((Math.max(0,f-82)+i*15)%46)/46;
        return <rect key={i} x={12+t*78} y={120} width="9" height="12" fill={C.lime} opacity={transfer*Math.sin(t*Math.PI)}/>;
      })}
      <g transform="translate(176 126)">
        <circle r="62" fill={C.panel} fillOpacity=".85" stroke={C.ice} strokeWidth="3"/>
        <circle r="37" fill="none" stroke={C.soft} strokeWidth="2"/>
        <circle r="11" fill={C.ice}/>
        {Array.from({length:10},(_,i)=><circle key={i} cx={48*Math.cos(i*Math.PI/5)} cy={48*Math.sin(i*Math.PI/5)} r="3" fill={C.soft}/>)}
        <path d="M39-49H68V33H45" fill={C.panelBright} stroke={C.lime} strokeWidth="4"/>
      </g>
      <g opacity={management}>
        {[0,1,2].map(i=><Vector key={i} x={265+i*48} y={125} dx={0} dy={-55-(i%2)*18} p={management} color={C.lime} width={2}/>)}
        <text x="18" y="249" {...svgText} fill={C.lime} fontSize="28" fontWeight="600">{T.B.heat}</text>
        <text x="18" y="294" {...svgText} fill={C.soft} fontSize="22">{T.B.heatNote}</text>
      </g>
    </svg>
  </OverlayFrame>;
};

export const Cornering:React.FC<P03Props> = ({reducedMotion}) => {
  const f=useCurrentFrame();
  const curve=progress(f,TIME.intro,28);
  const lateral=progress(f,TIME.evidence,18);
  const tyre=progress(f,TIME.second,18);
  const grip=progress(f,TIME.third,18);
  const t=reducedMotion?0.55:progress(f,32,111,Easing.linear);
  // Circular path with a centre at (40,286): required lateral force is radial inward.
  const theta=-Math.PI/2*t;
  const x=40+264*Math.cos(theta),y=286+264*Math.sin(theta);
  return <OverlayFrame id="C" f={f} reducedMotion={reducedMotion}>
    <Formula f={f} at={TIME.evidence} text={T.C.formula} reduced={reducedMotion}/>
    <SideHeading x={96} y={334} f={f} at={TIME.intro} label={T.C.path} tag="PATH" reduced={reducedMotion}/>
    <svg width="420" height="350" style={{...svgStyle,left:96,top:410,opacity:curve}}>
      <path d="M342 286A302 302 0 0 0 40-16M266 286A226 226 0 0 0 40 60" fill="none" stroke={C.soft} strokeOpacity=".5" strokeWidth="2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-curve}/>
      <path d="M304 286A264 264 0 0 0 40 22" fill="none" stroke={C.ice} strokeWidth="3" strokeDasharray="7 8"/>
      <path d="M40 286H55M40 286V271" fill="none" stroke={C.soft} strokeWidth="2"/>
      <PlanCar x={x} y={y} angle={theta*180/Math.PI-90} scale={0.64}/>
      <Vector x={x} y={y} dx={(40-x)*.40} dy={(286-y)*.40} color={C.lime} p={lateral}/>
      <g opacity={lateral}>
        <text x="155" y="259" {...svgText} fill={C.lime} fontSize="25">{T.C.force}</text>
        <text x="155" y="294" {...svgText} fill={C.soft} fontSize="21">{T.C.inward}</text>
      </g>
    </svg>
    <SideHeading x={1404} y={334} f={f} at={TIME.second} label={T.C.tyre} tag="TYRE" reduced={reducedMotion}/>
    <svg width="420" height="330" style={{...svgStyle,left:1404,top:410,opacity:tyre}}>
      <g transform="translate(110 130)">
        <rect x="-41" y="-61" width="82" height="122" rx="30" fill={C.panel} fillOpacity=".9" stroke={C.ice} strokeWidth="3"/>
        <path d="M-24-52V52M0-56V56M24-52V52" fill="none" stroke={C.soft} strokeOpacity=".5" strokeWidth="2"/>
        <ellipse cy="64" rx="34" ry="7" fill={C.lime} opacity={grip}/>
        <path d="M-76 77H76" stroke={C.soft} strokeWidth="2"/>
      </g>
      <Vector x={256} y={46} dx={0} dy={125} color={C.lime} p={tyre}/>
      <text x="284" y="107" {...svgText} fill={C.lime} fontSize="23">Fz</text>
      <g opacity={grip}>
        <text x="18" y="250" {...svgText} fill={C.lime} fontSize="25" fontWeight="600">{T.C.sensitivity}</text>
        <text x="18" y="291" {...svgText} fontSize="24">{T.C.grip}</text>
        <text x="18" y="328" {...svgText} fontSize="21" fill={C.soft}>{T.C.state}</text>
      </g>
    </svg>
  </OverlayFrame>;
};
