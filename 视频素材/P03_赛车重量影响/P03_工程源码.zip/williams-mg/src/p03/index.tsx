import React from 'react';
import {Composition, Folder} from 'remotion';
import {VIDEO} from '../project';
import {P03_LENGTH} from './config';
import {Acceleration, Braking, Cornering} from './Overlays';
import {AccelerationPreview, BrakingPreview, CorneringPreview, P03Demo} from './Preview';

const alphaDefaults=()=>({defaultCodec:'prores' as const,defaultProResProfile:'4444' as const,defaultPixelFormat:'yuva444p10le' as const,defaultVideoImageFormat:'png' as const});
export const P03Compositions:React.FC = () => <Folder name="P03-Weight-Overlays">
  <Composition id="P03-A" component={Acceleration} durationInFrames={P03_LENGTH.A} {...VIDEO} defaultProps={{reducedMotion:false}} calculateMetadata={alphaDefaults}/>
  <Composition id="P03-B" component={Braking} durationInFrames={P03_LENGTH.B} {...VIDEO} defaultProps={{reducedMotion:false}} calculateMetadata={alphaDefaults}/>
  <Composition id="P03-C" component={Cornering} durationInFrames={P03_LENGTH.C} {...VIDEO} defaultProps={{reducedMotion:false}} calculateMetadata={alphaDefaults}/>
  <Composition id="P03-A-Preview" component={AccelerationPreview} durationInFrames={P03_LENGTH.A} {...VIDEO} defaultProps={{reducedMotion:false,tone:'bright' as const,showGuides:true,showOverlay:true}}/>
  <Composition id="P03-B-Preview" component={BrakingPreview} durationInFrames={P03_LENGTH.B} {...VIDEO} defaultProps={{reducedMotion:false,tone:'dark' as const,showGuides:true,showOverlay:true}}/>
  <Composition id="P03-C-Preview" component={CorneringPreview} durationInFrames={P03_LENGTH.C} {...VIDEO} defaultProps={{reducedMotion:false,tone:'bright' as const,showGuides:true,showOverlay:true}}/>
  <Composition id="P03-Demo" component={P03Demo} durationInFrames={P03_LENGTH.A+P03_LENGTH.B+P03_LENGTH.C} {...VIDEO} defaultProps={{reducedMotion:false,showGuides:true}}/>
</Folder>;
