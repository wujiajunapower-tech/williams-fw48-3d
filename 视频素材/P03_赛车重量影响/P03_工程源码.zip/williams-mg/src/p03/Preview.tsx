import React from 'react';
import {AbsoluteFill, Img, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {P03_COLOR as C, P03_COPY as T, P03_LENGTH, PreviewProps} from './config';
import {Acceleration, Braking, Cornering} from './Overlays';

/** Original neutral illustration, ONLY mounted by preview compositions. */
const NeutralRacingPlate:React.FC<{tone:'bright'|'dark';showGuides:boolean}> = ({tone,showGuides}) => {
  const f=useCurrentFrame();
  const dark=tone==='dark';
  const drift=(f*9)%240;
  const carDrift=Math.sin(f/58)*9;
  return <AbsoluteFill className="scene" style={{background:dark?'#171E28':'#AFBAC3'}}>
    <svg width="1920" height="1080">
      <defs>
        <linearGradient id={`sky-${tone}`} x2="0" y2="1"><stop stopColor={dark?'#273442':'#D8E0E6'}/><stop offset="1" stopColor={dark?'#596775':'#9EADB8'}/></linearGradient>
        <linearGradient id={`track-${tone}`} x2=".4" y2="1"><stop stopColor={dark?'#59616B':'#9CA6AE'}/><stop offset="1" stopColor={dark?'#1C222B':'#66727D'}/></linearGradient>
      </defs>
      <rect width="1920" height="600" fill={`url(#sky-${tone})`}/>
      <path d="M0 435L1920 358V535H0Z" fill={dark?'#26323D':'#788A96'}/>
      <g opacity={dark?.34:.47} stroke={dark?'#9AA9B9':'#DDE5E8'} strokeWidth="3">
        {Array.from({length:12},(_,i)=><path key={i} d={`M0 ${420+i*10}L1920 ${346+i*10}`}/>)}
        {Array.from({length:18},(_,i)=><path key={i} d={`M${i*128-drift/3} 336v184`}/>)}
      </g>
      <path d="M0 520L1920 451V1080H0Z" fill={`url(#track-${tone})`}/>
      <path d="M-150 806L2050 559L2080 603L-150 865Z" fill={dark?'#798D9E':'#CBD4D9'}/>
      {Array.from({length:12},(_,i)=><path key={i} d={`M${i*240-drift-150} ${806-(i*240-drift)/8.9}l104-12 20 46-113 13Z`} fill={dark?'#304C65':'#667E91'}/>)}
      <path d="M0 968L1920 720" stroke={dark?'#75818B':'#BDC6CC'} strokeWidth="7" opacity=".55"/>
      <g opacity=".13" stroke={dark?'#AFC0D1':'#F1F5F6'}>
        {Array.from({length:9},(_,i)=><path key={i} d={`M${-500+i*330-drift} 1080l900-390`} strokeWidth="2"/>)}
      </g>
      <ellipse cx={960+carDrift} cy="788" rx="300" ry="27" fill="#000" opacity=".18"/>
    </svg>
    {/* Preview-only studio cutout. The transparent technical MOVs never mount it. */}
    <Img src={staticFile('p03/f1-car-v2.png')} style={{position:'absolute',left:565+carDrift,top:338,width:790,height:790*1024/1536,objectFit:'contain'}}/>
    {showGuides?<div style={{position:'absolute',left:96,top:914,width:1728,height:90,border:'1px dashed rgba(255,255,255,.35)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,color:'#DCE5EC',textShadow:'0 1px 4px #000'}}>{T.subtitle}</div>:null}
    <div style={{position:'absolute',left:96,top:1022,fontSize:20,color:dark?'#B7C3D0':'#DFE7ED',textShadow:'0 1px 4px #000',letterSpacing:1}}>{T.placeholder}</div>
  </AbsoluteFill>;
};

export const AccelerationPreview:React.FC<PreviewProps> = ({tone,showGuides,showOverlay=true,...props}) => <><NeutralRacingPlate tone={tone} showGuides={showGuides}/>{showOverlay?<Acceleration {...props}/>:null}</>;
export const BrakingPreview:React.FC<PreviewProps> = ({tone,showGuides,showOverlay=true,...props}) => <><NeutralRacingPlate tone={tone} showGuides={showGuides}/>{showOverlay?<Braking {...props}/>:null}</>;
export const CorneringPreview:React.FC<PreviewProps> = ({tone,showGuides,showOverlay=true,...props}) => <><NeutralRacingPlate tone={tone} showGuides={showGuides}/>{showOverlay?<Cornering {...props}/>:null}</>;

export const P03Demo:React.FC<{reducedMotion:boolean;showGuides:boolean}> = (props) => <>
  <Sequence durationInFrames={P03_LENGTH.A}><AccelerationPreview {...props} tone="bright" showOverlay/></Sequence>
  <Sequence from={P03_LENGTH.A} durationInFrames={P03_LENGTH.B}><BrakingPreview {...props} tone="dark" showOverlay/></Sequence>
  <Sequence from={P03_LENGTH.A+P03_LENGTH.B} durationInFrames={P03_LENGTH.C}><CorneringPreview {...props} tone="bright" showOverlay/></Sequence>
</>;
