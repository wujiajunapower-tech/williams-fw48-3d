/** Editorial content, design tokens and all timing in one place. */
export const VIDEO = {width: 1920, height: 1080, fps: 30} as const;
export const seconds = (s: number) => Math.round(s * VIDEO.fps);
export const LENGTH = {G01: seconds(12), G02: seconds(15)};

export const PALETTE = {
  background: '#060C18',
  panel: '#10233E',
  panelBright: '#163559',
  blue: '#397BFF',
  ice: '#9ACBFF',
  lime: '#D7F573',
  white: '#F6F8FC',
  muted: '#93A8C1',
  line: '#29415F',
};

export const CONTENT = {
  brand: 'KARCHUN RACING',
  asOf: '资料截至 2026-10-18',
  G01: {
    title: '期待与现实',
    subtitle: '威廉姆斯车队｜2025—2026',
    left: {year: '2025', period: '完整赛季', rankLabel: '车队年度排名', rank: 5, points: 137},
    right: {year: '2026', period: '截至新加坡站', rankLabel: '车队排名', rank: 9, points: 12},
    scope: '统计阶段不同，不计算同比降幅',
    question: '提前押注 2026，为何仍然掉队？',
    source: '来源 F1 官方车队积分榜  ·  S01 / S02',
  },
  G02: {
    title: '研发与制造如何衔接？',
    subtitle: '提前研发，不等于提前交付',
    research: ['概念设计', '气动研发', '设计方案'],
    manufacture: ['零件生产', '装配集成', '测试验证'],
    handoff: '研发推进 ≠ 制造与测试同步完成',
    conclusion: '风洞研发开始得早 ≠ 制造准备已经完成',
    scope: '一般性流程示意，不代表威廉姆斯车队内部生产计划',
    source: '依据 沃尔斯公开解释  ·  F1 官方采访 2026年5月  ·  S04',
  },
};

export const TIMING = {
  G01: {
    titleIn: seconds(0.2), titleMove: 43, titleMoveDuration: 22,
    leftIn: seconds(2), leftRank: seconds(2.9), leftPoints: seconds(3.65),
    rightIn: seconds(5), rightRank: seconds(5.9), rightPoints: seconds(6.65),
    comparison: seconds(8), question: seconds(10),
  },
  G02: {
    titleIn: seconds(0.2), regions: seconds(1.25),
    research: [seconds(3), seconds(3.8), seconds(4.6)],
    bridge: seconds(6),
    manufacture: [seconds(6.9), seconds(7.7), seconds(8.5)],
    explanation: seconds(9.2), conclusion: seconds(12),
  },
};

export type SceneProps = {reducedMotion: boolean};
export const DEFAULT_PROPS: SceneProps = {reducedMotion: false};
