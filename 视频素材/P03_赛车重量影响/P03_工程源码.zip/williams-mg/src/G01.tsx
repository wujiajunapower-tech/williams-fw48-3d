import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {CONTENT, PALETTE as C, TIMING, SceneProps} from './project';
import {IN_OUT, lerp, progress, settle} from './motion';
import {Background, Footer, FontGate, Reveal, RollingNumber, SceneTitle} from './components/Primitives';

const DataCard: React.FC<{
  frame: number; side: 'left'|'right'; reduced: boolean;
}> = ({frame,side,reduced}) => {
  const isLeft=side==='left';
  const data=CONTENT.G01[side];
  const t=TIMING.G01;
  const at=isLeft?t.leftIn:t.rightIn;
  const rankAt=isLeft?t.leftRank:t.rightRank;
  const pointsAt=isLeft?t.leftPoints:t.rightPoints;
  const p=progress(frame,at,reduced?8:30);
  const compare=progress(frame,t.comparison,25,IN_OUT);
  const space=progress(frame,t.question,25,IN_OUT);
  const delta=reduced?0:(1-p)*(isLeft?-1060:1060)+(isLeft?-16:16)*space;
  const color=isLeft?C.ice:C.lime;
  const accent=settle(frame,at+18);
  const metric=(start:number) => ({opacity:progress(frame,start-5,10),transform:`translateY(${reduced?0:(1-progress(frame,start-5,22))*20}px)`});
  return <div style={{position:'absolute',left:isLeft?104:1006,top:324,width:810,height:386,
    transform:`translateX(${delta}px) scale(${reduced?1:lerp(0.975,1,p)-space*0.015})`,
    opacity:Math.min(1,p*5),border:`1px solid ${isLeft?'#3C5D82':compare>0.1?'#809C54':'#3C5D82'}`,
    background:isLeft?'linear-gradient(115deg, rgba(29,65,106,.86), rgba(12,29,52,.9))':'linear-gradient(115deg, rgba(21,42,68,.94), rgba(10,24,42,.9))',
    boxShadow:'0 28px 65px rgba(0,0,0,.28)',borderRadius:3,overflow:'hidden'}}>
    <svg width="810" height="386" style={{position:'absolute',inset:0}}>
      <path d="M0 36V0H75 M735 386H810V350" fill="none" stroke={color} strokeWidth="3" opacity={0.6}/>
      <path d="M580 0L810 230 M640 0L810 170" stroke="#9ACBFF" opacity=".055" strokeWidth="1"/>
      <path d="M34 131H776" stroke="#607E9D" opacity=".28"/>
    </svg>
    <div style={{position:'absolute',left:34,top:21,color,display:'flex',alignItems:'baseline',gap:18}}>
      <span className="numerals" style={{fontSize:68,lineHeight:'82px',fontWeight:600}}>{data.year}</span>
      <span style={{fontSize:24,color:C.white,letterSpacing:1}}>赛季</span>
    </div>
    <Reveal frame={frame} at={at+12} reduced={reduced} style={{position:'absolute',right:34,top:48}}>
      <div style={{fontSize:23,lineHeight:'35px',padding:'1px 13px 3px',border:`1px solid ${color}65`,color,background:`${color}0D`}}>{data.period}</div>
    </Reveal>
    <div style={{position:'absolute',left:35,top:155,width:330,...metric(rankAt)}}>
      <div style={{color:C.muted,fontSize:25,letterSpacing:2,marginBottom:12}}>{data.rankLabel}</div>
      <div style={{display:'flex',alignItems:'baseline',height:150,gap:14}}>
        <span style={{fontSize:30,color:C.muted}}>第</span>
        <RollingNumber value={data.rank} frame={frame} at={rankAt} reduced={reduced} />
        <span style={{fontSize:30,color:C.muted}}>名</span>
      </div>
    </div>
    <div style={{position:'absolute',left:420,top:155,width:350,...metric(pointsAt)}}>
      <div style={{color:C.muted,fontSize:25,letterSpacing:2,marginBottom:12}}>车队{isLeft?'年度':''}积分</div>
      <div style={{display:'flex',alignItems:'baseline',height:150,gap:14}}>
        <RollingNumber value={data.points} frame={frame} at={pointsAt} reduced={reduced}/>
        <span style={{fontSize:30,color:C.muted}}>分</span>
      </div>
    </div>
    <div style={{position:'absolute',left:34,bottom:0,width:742,height:3,background:color,transformOrigin:'left',transform:`scaleX(${accent*(0.25+compare*0.75)})`,opacity:.65}}/>
  </div>;
};

export const G01: React.FC<SceneProps> = ({reducedMotion}) => {
  const frame=useCurrentFrame();
  const t=TIMING.G01;
  const scope=progress(frame,t.leftIn+28,20);
  return <AbsoluteFill className="scene">
    <FontGate/>
    <Background frame={frame} code="G01" reduced={reducedMotion}/>
    <SceneTitle frame={frame} at={t.titleIn} title={CONTENT.G01.title} subtitle={CONTENT.G01.subtitle} reduced={reducedMotion} introCenter moveAt={t.titleMove} moveDuration={t.titleMoveDuration}/>
    <DataCard frame={frame} side="left" reduced={reducedMotion}/>
    <DataCard frame={frame} side="right" reduced={reducedMotion}/>
    <div style={{position:'absolute',top:729,left:96,width:1728,textAlign:'center',fontSize:25,color:C.muted,opacity:scope,letterSpacing:1}}>
      <span style={{color:C.lime,marginRight:12}}>／</span>{CONTENT.G01.scope}
    </div>
    <Reveal frame={frame} at={t.question+2} duration={28} reduced={reducedMotion} style={{position:'absolute',top:779,left:96,width:1728,height:56,textAlign:'center'}}>
      <div style={{fontSize:42,lineHeight:'54px',fontWeight:600,letterSpacing:-1}}>{CONTENT.G01.question}</div>
    </Reveal>
    <Footer frame={frame} at={t.leftIn+15} source={CONTENT.G01.source}/>
  </AbsoluteFill>;
};
