import React from 'react';
import {Composition, Sequence} from 'remotion';
import {G01} from './G01';
import {G02} from './G02';
import {LENGTH, SceneProps, VIDEO} from './project';
import {P03Compositions} from './p03';

const Demo:React.FC<SceneProps> = (props) => <>
  <Sequence durationInFrames={LENGTH.G01}><G01 {...props}/></Sequence>
  <Sequence from={LENGTH.G01} durationInFrames={LENGTH.G02}><G02 {...props}/></Sequence>
</>;

export const Root:React.FC = () => <>
  <Composition id="G01" component={G01} durationInFrames={LENGTH.G01} {...VIDEO} defaultProps={{reducedMotion:false}}/>
  <Composition id="G02" component={G02} durationInFrames={LENGTH.G02} {...VIDEO} defaultProps={{reducedMotion:false}}/>
  <Composition id="Demo" component={Demo} durationInFrames={LENGTH.G01+LENGTH.G02} {...VIDEO} defaultProps={{reducedMotion:false}}/>
  <P03Compositions/>
</>;
