#!/bin/bash
cd "$(dirname "$0")"
exec ./run.sh preview
